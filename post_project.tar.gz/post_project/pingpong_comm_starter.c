#include <stdio.h>
#include <unistd.h>
#include <mpi.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

// Example compilation
// mpicc pingpong_comm_starter.c -lm -o pingpong_comm_starter

// Example execution
// mpirun -np 2 -hostfile myhostfile.txt ./pingpong_comm_starter

int main(int argc, char **argv)
{
	int my_rank, nprocs;

	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &my_rank);
	MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
	MPI_Status status;

	// make sure even number of procs
	if ((nprocs % 2) != 0)
	{
		if (my_rank == 0)
		{
			printf("\nYou must enter an even number of process ranks");
		}
		MPI_Finalize();
		return 0;
	}
	// Write code here
	/* 定义循环次数为5 */
	int loop_count = 5;
	/* 用于存储对端的node id */
	int peer_node = 0;
	/* 用于存储对端传输过来的rank_id */
	int peer_rank_id = 0;
	/* 用于存储累加结果 */
	int local_counter = 0;

	if (my_rank % 2 == 0) {
		/* 偶数结点先发送 */
		peer_node = my_rank + 1;
		for (int i = 0; i < loop_count; i ++) {
			MPI_Send(&my_rank, 1, MPI_INT, peer_node, 0, MPI_COMM_WORLD);
			MPI_Recv(&peer_rank_id, 1, MPI_INT, peer_node, 0, MPI_COMM_WORLD, &status);
			local_counter += peer_rank_id;
		}
	} else {
		/* 奇数结点先接收 */
		peer_node = my_rank - 1;
		for (int i = 0; i < loop_count; i ++) {
			MPI_Recv(&peer_rank_id, 1, MPI_INT, peer_node, 0, MPI_COMM_WORLD, &status);
			local_counter += peer_rank_id;
			MPI_Send(&my_rank, 1, MPI_INT, peer_node, 0, MPI_COMM_WORLD);
		}
	}
	printf("本地进程号为: %d, 总进程数为: %d, 累加计数器为: %d, 循环次数为: %d\n", my_rank, nprocs, local_counter, loop_count);

	MPI_Finalize();
	return 0;
}


